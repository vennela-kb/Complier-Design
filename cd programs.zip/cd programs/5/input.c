main()
{
int a, sum;
float A[MAX], x;
a=25;
x=54;
if(a<=x)
then
printf("Minimum is a");
else
printf("Maximum is x");
}