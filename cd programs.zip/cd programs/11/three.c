#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
#define MAX 25
static int reg = 0;
int top = -1;
char stk[MAX];
char temp='1';
void getregister();
void pop();
void push(char);
void empty();
void main()
{
int i;
char postfix[10];
//clrscr();
printf("\nEnter Postfix Expression:");
scanf("%s", postfix);
i=0;
while(postfix[i]!='\0')
{
while(islower(postfix[i])!=0)
{
push(postfix[i]);
i++;
}
getregister();
printf("\nLOAD %c R%d", stk[top-1], reg);
switch(postfix[i])
{
case '+':
printf("\nADD %c R%d\n", stk[top], reg);
empty();
i++;
break;
case '*':
printf("\nMUL %c R%d",stk[top], reg);
empty();
i++;
break;
case '-':
printf("\nSUB %c R%d",stk[top], reg);
empty();
i++;
break;
case '/':
printf("\nDIV %c R%d",stk[top], reg);
empty();
i++;
break;
default:
printf("\nInvalid Instruction.");
getch();
exit(0);
}
}
getch();
}
void empty()
{
char t1;
pop();
pop();
printf("\nSTR R%d T%c", reg,temp);
t1 = temp;
temp++;
push(t1);
}
void getregister()
{
reg++;
if(reg>2)
reg = 1;
}
void push(char x)
{
if(top==MAX-1)
printf("\nStack is Full.\n");
else
{
top++;
stk[top] = x;
}
}
void pop()
{
if(top == -1)
printf("\nStack is Empty.\n");
else
top--;
}