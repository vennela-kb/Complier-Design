#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
void main()
{
int i, size;
char pfix[25], ch;
void TAC(char *, int);
printf("\nEnter postfix expression:");
i=0;
while((ch=getchar())!='\n')
{
pfix[i]=ch;
i++;
}
pfix[i]='\0';
printf("\nPostfix Expression:%s",pfix);
size=i;
TAC(pfix, size);
}
void TAC(char pf[25], int s)
{
char stack[25], *str;
int top=0, i, j;
char temp;
char tac_arg1[25], tac_arg2[25], tac_op[25], tac_res[25];
j=-1;
temp=91;
for(i=0;i<s;i++)
{
if(isalpha(pf[i]))
stack[top++]=pf[i];
else if(pf[i]=='+' || pf[i]=='-'||pf[i]=='/'|| pf[i]=='*'|| pf[i]=='=')
{
j = j + 1;
temp = temp - 1;
tac_arg2[j]=stack[--top];
tac_arg1[j]=stack[--top];
tac_op[j]=pf[i];
tac_res[j]=temp;
stack[top++]=temp;
}
}
printf("\n\n\nIntermediate Code(TAC)");
printf("\n_______________________________\n");
for(i=0;i<=j; i++)
printf("%2c = %2c %2c %2c\n", tac_res[i], tac_arg1[i], tac_op[i], tac_arg2[i]);
printf("\n_______________________________\n");
}